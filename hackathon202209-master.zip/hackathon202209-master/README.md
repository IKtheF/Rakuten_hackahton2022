# Overall
these projects are made via "create react app" command.
and you can run this with just npm start.
