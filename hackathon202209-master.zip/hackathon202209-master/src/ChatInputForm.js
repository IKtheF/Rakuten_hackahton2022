import logo from './logo.png';

function ChatInputForm() {
  return (
    <div className="ChatInputForm">
    </div>
  );
}

export default ChatInputForm;
