import logo from './logo.png';

function Header() {
  return (
    <div className="Header">
      <header className="App-header">
        <img src={logo} className="Header-logo"/>
      </header>
    </div>
  );
}

export default Header;
